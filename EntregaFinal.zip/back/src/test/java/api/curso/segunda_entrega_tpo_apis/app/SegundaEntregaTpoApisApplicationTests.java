package api.curso.segunda_entrega_tpo_apis.app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SegundaEntregaTpoApisApplicationTests {

	@Test
	void contextLoads() {
	}

}
