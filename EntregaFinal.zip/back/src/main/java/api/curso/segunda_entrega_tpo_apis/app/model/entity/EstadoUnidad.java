package api.curso.segunda_entrega_tpo_apis.app.model.entity;

public enum EstadoUnidad {
    HABITADA,
    ALQUILADA,
    VACIA
}

