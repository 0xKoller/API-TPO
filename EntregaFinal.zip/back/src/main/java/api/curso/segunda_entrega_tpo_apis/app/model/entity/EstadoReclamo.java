package api.curso.segunda_entrega_tpo_apis.app.model.entity;

public enum EstadoReclamo {
    NUEVO,
    ABIERTO,
    EN_PROCESO,
    DESESTIMADO,
    ANULADO,
    TERMINADO
}

