package api.curso.segunda_entrega_tpo_apis.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SegundaEntregaTpoApisApplication {

	public static void main(String[] args) {
		SpringApplication.run(SegundaEntregaTpoApisApplication.class, args);
	}

}
