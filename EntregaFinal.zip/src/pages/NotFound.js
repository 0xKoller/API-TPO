import React from "react";

export default function NotFound() {
	return (
		<>
			<p>Not found</p>
		</>
	);
}
